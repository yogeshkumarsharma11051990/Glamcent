<?php

namespace OpenTok\Exception;

/**
* The interface used by all exceptions in the OpenTok PHP API.
*/
interface Exception
{
}
