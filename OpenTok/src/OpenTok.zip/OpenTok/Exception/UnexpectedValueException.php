<?php

namespace OpenTok\Exception;

/**
* Defines an exception thrown in result of an unexpected value.
*/
class UnexpectedValueException extends \UnexpectedValueException implements Exception
{
}
