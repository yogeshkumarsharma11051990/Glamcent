<?php

namespace OpenTok\Exception;

/**
* Defines an exception thrown when you pass an invalid argument into a method.
*/
class InvalidArgumentException extends \InvalidArgumentException implements Exception
{
}
