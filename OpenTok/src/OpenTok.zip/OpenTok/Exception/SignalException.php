<?php

namespace OpenTok\Exception;

/**
* The interface used by all exceptions resulting from calls to the signal API.
*/
interface SignalException
{
}
